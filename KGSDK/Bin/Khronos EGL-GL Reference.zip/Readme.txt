Source: Khronos.org
-------------------